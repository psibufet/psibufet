<div class="newsletterConfirm psibufetPopup" data-name="confirm">
    <div class="newsletterConfirm__wrap wrap">
        <div class="closebtn"></div>
        <div class="newsletterConfirm__content">
            <h2><span class="marker">Potwierdź</span> adres e-mail</h2>
            <p>Wejdź na swoją skrzynkę mailową i potwierdź zapis do Newslettera, aby otrzymać kod zniżkowy na dwie pierwsze dostawy.</p>
            <p>Jeśli nie widzisz wiadomości, sprawdź inne zakładki.</p>
            <img src="https://psibufet.pl/wp-content/themes/psibufet/images/popup/newsletter_confirm.gif"/>
        </div>
    </div>
</div>